# HANFIS: paket unduhan (7 November 2026)

Satu arsip untuk dikerjakan di tempat lain. Isinya naskah (PDF dan sumber yang bisa dikompilasi), semua markdown serah terima, memori proyek terbaru, dan laporan harian terakhir.

## 1. Di mana naskah terbaru

| Apa | Lokasi di mesin penelitian (repositori) | Di arsip ini |
|---|---|---|
| Naskah utama (PDF, 53 halaman) | `C:\Research\ANFIS\manuscript\sn-article.pdf` (WSL: `/mnt/c/Research/ANFIS/manuscript/sn-article.pdf`) | `naskah_pdf/sn-article_2026-11-07.pdf` |
| Additional file 1 (PDF, 15 halaman) | `C:\Research\ANFIS\manuscript\additional_file_1.pdf` | `naskah_pdf/additional_file_1_2026-11-07.pdf` |
| Sumber naskah (LaTeX) | `C:\Research\ANFIS\manuscript\sn-article.tex` dan `additional_file_1.tex` | `naskah_sumber/` |
| Bibliografi | `C:\Research\ANFIS\manuscript\sn-bibliography.bib` | `naskah_sumber/` |
| Memori proyek | `C:\Research\ANFIS\HANFIS_RESEARCH_MEMORY.md` | `memori/HANFIS_RESEARCH_MEMORY_v2.66.md` |

Sumber kebenaran tetap repositori (cabang `research/amend-a02-a06`, komit terbaru ada di GitHub `udahafeez7/HANFIS-RESEARCH`). Salinan di arsip ini adalah potret 7 November 2026; bila Anda mengedit di tempat lain, kirim perubahan sebagai pasangan teks lama dan teks baru agar bisa diterapkan lewat skrip teks-persis di repositori.

## 2. Isi arsip

```
00_BACA_DULU_lokasi_dan_isi.md       berkas ini
markdown/                            00 sampai 13: README dan prompt pembuka, status naskah, teks inti, hasil E7 dan aturan klaim,
                                     indeks Additional file 1, tugas terbuka, aturan menulis, benchmark dan pencocokannya,
                                     hasil E25, audit klaim berlebih, hasil E26 dan E27, aturan model, perbandingan flat lawan HANFIS
naskah_pdf/                          dua PDF naskah saat ini
naskah_sumber/                       .tex, .bib, .bst, .cls, dan lima gambar PDF: cukup untuk mengompilasi
memori/                              memori proyek v2.66 (amendemen A-1 sampai A-86)
laporan/                             laporan harian 3 November (Word) dan rencana 4 November
```

Mulai dari `markdown/00_README_dan_prompt_pembuka.md`: ada prompt pembuka untuk aplikasi Claude dan daftar semua berkas.

## 3. Cara mengompilasi di tempat lain

Uji dari salinan bersih arsip ini: naskah 53 halaman, Additional file 1 15 halaman, tanpa referensi tak terdefinisi.

Di komputer dengan TeX Live atau MiKTeX, dari folder `naskah_sumber/`:

```bash
pdflatex -interaction=nonstopmode sn-article.tex
bibtex sn-article
pdflatex -interaction=nonstopmode sn-article.tex
pdflatex -interaction=nonstopmode sn-article.tex
pdflatex -interaction=nonstopmode additional_file_1.tex
bibtex additional_file_1
pdflatex -interaction=nonstopmode additional_file_1.tex
pdflatex -interaction=nonstopmode additional_file_1.tex
```

Urutan penting: naskah utama dulu, karena Additional file 1 mengambil nomor rujukan dari `sn-article.aux` (paket `xr-hyper`). Di Overleaf, unggah semua isi `naskah_sumber/`, jadikan `sn-article.tex` berkas utama, kompilasi, lalu ganti berkas utama ke `additional_file_1.tex` dan kompilasi lagi. Peringatan "Citation prometheus_overview multiply defined" di Additional file 1 tidak berbahaya.

## 4. Keadaan singkat

- E7 selesai dan terkunci (tag `e7-results-2026-11-02`). E25 (biaya komputasi), E26 (ablasi x7), E27 (dokumentasi aturan) selesai; ketiganya post hoc atau deskriptif, tidak terdaftar, dijalankan setelah E7 tanpa data E7.
- Naskah: kata badan sekitar 12.430, abstrak 247 kata, 11 tabel dan 3 gambar di badan. Judul tetap.
- Hasil utama jujur: HANFIS tidak mengalahkan persistence maupun rumus empat parameter; keunggulan atas CVSS, ridge, dan flat ANFIS nyata di E4-bis tetapi sebagian dari satu fold; E25 menunjukkan waktu latih dan latensi satu baris tidak lebih baik; E27 menunjukkan label linguistik variabel antara tidak stabil.
- Tugas terbuka (lengkapnya di `markdown/05_...`): daftar kandidat referensi untuk Literature Review (referensi harus dibaca dan diambil lewat doi.org, tidak dari ingatan), pemangkasan ulang naskah, baca ulang utuh, kebijakan AI Springer, volume dan halaman Holm, Zenodo (ditunda). Tenggat kirim 5 Desember 2026.

## 5. Aturan yang tetap berlaku

- Tidak ada analisis tambahan atau penyetelan atas hasil E7; tanpa `--today`; `evaluate` dan `formula` tidak diulang.
- Berkas beku E7 (23 berkas, tag `e7-prereg-2026-10-12`) tidak diubah.
- Analisis baru ditandai post hoc atau tidak terdaftar, dengan protokol dikomit sebelum dijalankan.
- Hasil negatif dilaporkan apa adanya. Jangan menulis sitasi dari ingatan.
- Perubahan naskah di repositori lewat skrip teks-persis yang gagal-tertutup dan diuji di salinan.

## 6. Sidik jari berkas (sha256, 16 karakter pertama)

| Berkas | sha256 |
|---|---|
| `naskah_sumber/sn-article.tex` | `8f0dd428e141a4ad` |
| `naskah_pdf/sn-article_2026-11-07.pdf` | `90429b55e53d5f22` |
| `naskah_sumber/additional_file_1.tex` | `d092db724517c162` |
| `naskah_pdf/additional_file_1_2026-11-07.pdf` | `1080a20928167586` |
| `memori/HANFIS_RESEARCH_MEMORY_v2.66.md` | `4ce378df7f3b6b22` |

---
Dokumen ini disusun dengan bantuan asisten AI (Claude, Anthropic) dari keadaan repositori pada 7 November 2026.
